package com.example.hashassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    public HashSet<String> hs = new HashSet<String>();
    public HashMap hm = new HashMap();
    public TextView s;
    public TextView smt;
    public int inc = 0;
    public int incr = 0;
    public String strSet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        s = findViewById(R.id.displayText);
        smt = findViewById(R.id.setMapText);
    }

    public void hashMapButton(View v){
        if(incr == 0){
            strSet = "the map is empty";
            smt.setText("");
        }
        else if(incr == 1){
            strSet = "adds our first key/value pair";
            hm.put(1,"rice");
            smt.setText(mapAsText(hm));
        }
        else if(incr == 2){
            strSet = "adds a few more key/value pairs";
            hm.put(2,"beans");
            hm.put(3,"tomatoes");
            hm.put(4,"corn");
            smt.setText(mapAsText(hm));
        }
        else if(incr == 3){
            strSet = "adds a duplicate key (replaces corn with spinach)";
            hm.put(4, "spinach");
            smt.setText(mapAsText(hm));
        }
        else if(incr == 4){
            strSet = "adds a duplicate value with a new key";
            hm.put(5,"rice");
            smt.setText(mapAsText(hm));
        }
        else if(incr == 5){
            strSet = "is the key '5' in the map?";
            smt.setText(Boolean.toString(hm.containsKey(5)));
        }
        else if(incr == 6){
            strSet = "is the key '6' in the map?";
            smt.setText(Boolean.toString(hm.containsKey(6)));
        }
        else if(incr == 7){
            strSet = "gets a list of the keys";
            smt.setText(getKeys(hm));
        }
        else if(incr == 8){
            strSet = "removes '1=rice' from the hash map";
            hm.remove(1);
            smt.setText(mapAsText(hm));
        }
        else{
            strSet = "Nothing else to change";
        }
        //sets string to say what the button changed
        s.setText(strSet);
        incr++;
    }

    public String getKeys(HashMap h){
        Set mySet = hm.entrySet();
        Iterator iterator = mySet.iterator();
        ArrayList<String> keys = new ArrayList<String>();
        while(iterator.hasNext()){
            Map.Entry e = (Map.Entry)iterator.next();
            keys.add(e.getKey().toString());
        }
        return(keys.toString());
    }

    public String mapAsText(HashMap h){
        Set mySet = hm.entrySet();
        return(mySet.toString());
    }

    public void hashSetButton(View v){

        if(inc == 0){
            strSet = "displays the (empty) set";
            smt.setText(hs.toString());
        }
        else if(inc==1){
            strSet = "Adds 'milk' to set";
            hs.add("milk");
            smt.setText(hs.toString());
        }
        else if(inc == 2){
            strSet = "Adds 'bread' to set";
            hs.add("bread");
            smt.setText(hs.toString());
        }
        else if(inc == 3){
            strSet = "Adds 'cereal' to set";
            hs.add("cereal");
            smt.setText(hs.toString());
        }
        else if(inc == 4){
            strSet = "Adds 'bread' to set (again)";
            hs.add("bread");
            smt.setText(hs.toString());
        }
        else if(inc == 5){
            strSet = "Is 'bread' really in the set?";
            smt.setText(Boolean.toString(hs.contains("bread")));
        }
        else if(inc == 6){
            strSet = "Did we add 'butter' to the set?";
            smt.setText(Boolean.toString(hs.contains("butter")));
        }
        else if(inc == 7){
            strSet = "Let's remove 'bread' from the set.";
            hs.remove("bread");
            smt.setText(hs.toString());
        }
        else{
            strSet = "Nothing else to change";
        }

        //sets string to say what the button changed
        s.setText(strSet);
        inc++;
    }
}
